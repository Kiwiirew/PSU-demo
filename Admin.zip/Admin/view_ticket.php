<?php
include 'db_conn.php';

// Get ticket ID from URL
$id = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id) {
    header('Location: ticketsupport.php');
    exit;
}

// Fetch ticket details
$sql = "SELECT * FROM tickets WHERE id = " . intval($id);
$result = mysqli_query($conn, $sql);
$ticket = mysqli_fetch_assoc($result);

if (!$ticket) {
    header('Location: ticketsupport.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>PSU ASINGAN CAMPUS - View Ticket</title>
    <meta content="Admin Dashboard" name="description" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Include all the same CSS and assets as ticketsupport.php -->
    <link rel="shortcut icon" href="../assets/img/logotitle.png" type="image/x-icon">
    <link rel="icon" href="../assets/img/logotitle.png" type="image/x-icon">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
    <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body class="fixed-left">
    <!-- Loader -->
    <div class="preloader" id="preloader">
        <div class="lds-ellipsis">
            <span></span>
            <span style="background:#0A27D8"></span>
            <span style="background: #222429;"></span>
        </div>
    </div>

    <!-- Begin page -->
    <div id="wrapper">
        <!-- Include left sidebar -->
        <?php include('leftnavbar.php') ?>

        <!-- Start right Content here -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content">
                <!-- Include top navbar -->
                <?php include('topnavbar.php') ?>

                <div class="page-content-wrapper">
                    <div class="container-fluid" style="padding-top:30px;">
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="header-title pb-3 mt-0">Ticket Details</h5>
                                        
                                        <div class="ticket-details">
                                            <p><strong>First Name:</strong> <?php echo htmlspecialchars($ticket['first_name']); ?></p>
                                            <p><strong>Last Name:</strong> <?php echo htmlspecialchars($ticket['last_name']); ?></p>
                                            <p><strong>Email:</strong> <?php echo htmlspecialchars($ticket['email']); ?></p>
                                            <p><strong>Department:</strong> <?php echo htmlspecialchars($ticket['department']); ?></p>
                                            <p><strong>Description:</strong> <?php echo htmlspecialchars($ticket['description']); ?></p>
                                            
                                            <!-- Image Gallery -->
                                            <div class="image-gallery" style="margin-top: 20px;">
                                                <?php
                                                $screenshots = json_decode($ticket['screenshot'], true);
                                                if (is_array($screenshots) && !empty($screenshots)) {
                                                    foreach ($screenshots as $screenshot) {
                                                        if (!empty($screenshot)) {
                                                            echo "<img src='../uploads/" . htmlspecialchars($screenshot) . "' 
                                                                  class='gallery-img' 
                                                                  style='width: 150px; height: auto; margin: 5px; cursor: pointer; border: 1px solid #ddd; padding: 5px;' 
                                                                  onclick='openFullscreen(this.src)'>";
                                                        }
                                                    }
                                                } else if (!empty($ticket['screenshot'])) {
                                                    echo "<img src='../uploads/" . htmlspecialchars($ticket['screenshot']) . "' 
                                                          class='gallery-img' 
                                                          style='width: 150px; height: auto; margin: 5px; cursor: pointer; border: 1px solid #ddd; padding: 5px;' 
                                                          onclick='openFullscreen(this.src)'>";
                                                }
                                                ?>
                                            </div>

                                            <!-- Respond Button -->
                                            <div style="margin-top: 20px; text-align: right;">
                                                <button onclick="composeEmail('<?php echo htmlspecialchars($ticket['email']); ?>', 
                                                                            '<?php echo htmlspecialchars($ticket['first_name'] . ' ' . $ticket['last_name']); ?>', 
                                                                            '<?php echo htmlspecialchars($ticket['description']); ?>')" 
                                                        class="btn btn-primary">
                                                    <i class="fas fa-reply"></i> Respond
                                                </button>
                                                <a href="ticketsupport.php" class="btn btn-secondary">
                                                    <i class="fas fa-arrow-left"></i> Back to List
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <footer class="footer">
                © 2024 PSU ASINGAN CAMPUS
            </footer>
        </div>
    </div>

    <!-- Include all the same scripts as ticketsupport.php -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/modernizr.min.js"></script>
    <script src="assets/js/detect.js"></script>
    <script src="assets/js/fastclick.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/jquery.blockUI.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/jquery.nicescroll.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/plugins/chart.js/chart.min.js"></script>
    <script src="assets/pages/dashboard.js"></script>
    <script src="assets/js/app.js"></script>

    <!-- Add the email composition and fullscreen image viewing functions -->
    <script>
    function composeEmail(email, name, description) {
        const subject = `Re: IT Support Ticket - ${name}`;
        const body = `\n\n----------\nOriginal Message:\n${description}`;
        const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(email)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        window.open(gmailUrl, '_blank');
    }

    function openFullscreen(imgSrc) {
        window.open(imgSrc, '_blank');
    }
    </script>
</body>
</html> 