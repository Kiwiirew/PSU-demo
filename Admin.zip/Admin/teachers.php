<?php
include 'db_conn.php'; 

$sql = "SELECT COUNT(*) as count FROM teachers";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $count = $row['count'];
} else {
    $count = 0; 
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>PSU ASINGAN CAMPUS</title>
        <meta content="Admin Dashboard" name="description" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="../assets/img/logotitle.png" type="image/x-icon">
        <link rel="icon" href="../assets/img/logotitle.png" type="image/x-icon">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">

        <link rel="stylesheet" href="assets/css/custom.css">
    </head>

 <!-- oncontextmenu="return false" -->
    <body class="fixed-left">

        <!-- Loader -->
<div class="preloader" id="preloader">
            <div class="lds-ellipsis">
                <span></span>
                 <!-- <span  style="background:#FFAA17"></span> -->
                <span  style="background:#0A27D8"></span>
                <span  style="background: #222429;"></span>
            </div>
        </div>
        <!-- Begin page -->
        <div id="wrapper">

            <!-- ========== Left Sidebar Start ========== -->
            <?php include('leftnavbar.php') ?>
            <!-- Left Sidebar End -->

            <!-- Start right Content here -->

            <div class="content-page">
                <!-- Start content -->
                <div class="content">

                    <!-- Top Bar Start -->
                   
                    <?php include('topnavbar.php') ?>
                    <!-- Top Bar End -->

                    <div class="page-content-wrapper">

                        <div class="container-fluid"  style="padding-top:30px;">

                        
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="card">                                
                                        <div class="card-body">
                                           <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center">
                    <!-- Title -->
                    <h5 class="text-center header-title pb-3 mt-0">All Teachers (<span style="color:#0A27D8"><?php echo $count; ?></span>)</h5>
                    
                    <!-- Right-aligned elements for desktop, centered for mobile -->
                    <div class="d-flex flex-column flex-md-row align-items-md-center mt-3 mt-md-0">
                        <!-- Button and input container -->
                        <div class="text-center text-md-end" style="margin-right: 10px;">
                        <a href="javascript:void(0);" data-toggle="modal" data-target="#newTeacherModal">
                            <button class="btn btn-primary me-md-2 mb-2 mb-md-0">Add New Teacher</button>
                        </a>
                        <!-- Add Print Button -->
                        <button class="btn btn-success me-md-2 mb-2 mb-md-0" onclick="printTeachersByDepartment()">
                            <i class="fas fa-print"></i> Print Report
                        </button>
                        </div>
                        <div class="text-center text-md-end" style="margin: auto;">
                            <input type="text" id="searchInput" class="form-control" autocomplete="off" placeholder="Search Here" style="max-width: 200px;">
                        </div>
                    </div>
                </div>

                                                    <!-- Modal for Adding a New Teacher -->
                                    <div class="modal fade" id="newTeacherModal" tabindex="-1" role="dialog" aria-labelledby="newTeacherModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="newTeacherModalLabel">Add New Teacher</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form id="newTeacherForm" action="add_teachers.php" method="POST">
                                                        <div class="form-group">
                                                            <label for="fullname">Full Name</label>
                                                            <input type="text" class="form-control" id="fullname" name="fullname" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="department">Department</label>
                                                            <select class="form-control" id="department" name="department" required>
                                                                <option value="">Select Department</option>
                                                                <option value="BSIT">Bachelor of Science in Information Technology</option>
                                                                <option value="BSBA">Bachelor of Science in Business Administration</option>
                                                                <option value="BTLE">Bachelor of Technology and Livelihood Education</option>
                                                                <option value="BEE">Bachelor of Elementary Education</option>
                                                                <option value="BSE">Bachelor of Secondary Education</option>
                                                                <option value="BIT">Bachelor of Industrial Technology</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="designation">Designation</label>
                                                            <input type="text" class="form-control" id="designation" name="designation" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="teacherEmail">Email</label>
                                                            <input type="email" class="form-control" id="teacherEmail" name="teacherEmail" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="pnumber">Phone Number</label>
                                                            <input type="number" class="form-control" id="pnumber" name="pnumber" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="gender">Gender</label>
                                                            <select class="form-control" id="gender" name="gender" required>
                                                                <option value="" disabled selected>Select Gender</option>
                                                                <option value="Male">Male</option>
                                                                <option value="Female">Female</option>
                                                                <option value="Other">Other</option>
                                                            </select>
                                                        </div>
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Add Teacher</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Edit Teacher Modal -->
                                    <div class="modal fade" id="editTeacherModal" tabindex="-1" role="dialog" aria-labelledby="editTeacherModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="editTeacherModalLabel">Edit Teacher</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <!-- Form for Editing Teacher -->
                                                    <form id="editTeacherForm" action="update_teacher.php" method="POST">
                                                        <input type="hidden" id="editTeacherID" name="TeacherID">

                                                        <div class="form-group">
                                                            <label for="editFullName">Full Name</label>
                                                            <input type="text" class="form-control" id="editFullName" name="FullName" required>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="editdepartment">Department</label>
                                                            <select class="form-control" id="editdepartment" name="Department" required>
                                                                <option value="">Select Department</option>
                                                                <option value="BSIT">Bachelor of Science in Information Technology</option>
                                                                <option value="BSBA">Bachelor of Science in Business Administration</option>
                                                                <option value="BTLE">Bachelor of Technology and Livelihood Education</option>
                                                                <option value="BEE">Bachelor of Elementary Education</option>
                                                                <option value="BSE">Bachelor of Secondary Education</option>
                                                                <option value="BIT">Bachelor of Industrial Technology</option>
                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="editDesignation">Designation</label>
                                                            <input type="text" class="form-control" id="editDesignation" name="Designation" required>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="editEmail">Email</label>
                                                            <input type="email" class="form-control" id="editEmail" name="Email" required>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label for="editPhoneNumber">Phone Number</label>
                                                            <input type="text" class="form-control" id="editPhoneNumber" name="PhoneNumber" required>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="editGender">Gender</label>
                                                            <select class="form-control" id="editGender" name="Gender" required>
                                                                <option value="" disabled selected>Select Gender</option>
                                                                <option value="Male">Male</option>
                                                                <option value="Female">Female</option>
                                                                <option value="Other">Other</option>
                                                            </select>
                                                        </div>
                                                    </form>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="submit" form="editTeacherForm" class="btn btn-primary">Save Changes</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                            <div class="table-responsive" style="margin-top: 20px;">
                                            <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                    <thead>
                                                        <tr class="align-self-center">
                                                            <th>Full Name</th>
                                                            <th>Department</th>
                                                            <th>Designation</th>
                                                            <th>Email</th>
                                                            <th>Phone Number</th>
                                                            <th>Gender</th>
                                                            <th>Actions</th>                                                                                  
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                           <?php
                                                            include 'db_conn.php'; // Make sure this file connects to your database

                                                            // SQL query to select all data from Students
                                                            $sql = "SELECT * FROM teachers";
                                                            $result = $conn->query($sql);






                                                            // Check if the query was successful
                                                            if ($result->num_rows > 0) {
                                                                // Output data of each row
                                                                while($row = $result->fetch_assoc()) {

                                                                    $imageSrc = ($row['Gender'] == 'Male') ? 'assets/images/manteacher.png' : 'assets/images/womanteacher.svg';


                                                                    echo '<tr>';
                                                                    echo '<td><img src="' . $imageSrc . '" alt="" class="rounded-circle thumb-sm mr-1"> ' . htmlspecialchars($row['FullName']) . '</td>';
                                                                    echo '<td>' . htmlspecialchars($row['Department']) . '</td>';
                                                                    echo '<td>' . htmlspecialchars($row['Designation']) . '</td>';
                                                                    echo '<td>' . htmlspecialchars($row['Email']) . '</td>';
                                                                    echo '<td>' . htmlspecialchars($row['PhoneNumber']) . '</td>';
                                                                    echo '<td>' . htmlspecialchars($row['Gender']) . '</td>';
                                                                    echo '<td>';
                                                                    // echo '<button type="button" class="btn btn-sm btn-primary" style="margin:5px"><i class="fas fa-eye"></i> View</button>';
                                                                    echo '<button type="button" class="edit-button btn btn-sm" style="margin:5px;background:#FFD500" data-toggle="modal" data-target="#editTeacherModal" onclick="editTeacher(' . $row['TeacherID'] . ')"><i class="fas fa-edit"></i> Edit</button>';
                                                                    echo '<button type="button" class="btn btn-sm btn-danger" onclick="deleteRecord(' . $row['TeacherID'] . ')"><i class="fas fa-trash-alt"></i></button>';
                                                                    echo '</td>';
                                                                    echo '</tr>';
                                                                }
                                                            } else {
                                                                // If no results found
                                                                echo '<tr><td colspan="4">No Teachers Found</td></tr>';
                                                            }
                                                            ?>                                                                  
                                                    </tbody>
                                                </table>
                                            </div><!--end table-responsive-->
                                           
                                        </div>
                                    </div>                                                                   
                                </div> 
                            </div>
                            <!-- end row -->
                            
                        </div><!-- container -->

                    </div> <!-- Page content Wrapper -->

                </div> <!-- content -->

                <footer class="footer">
                    © 2024 PSU ASINGAN CAMPUS
                </footer>

            </div>
            <!-- End Right content here -->

        </div>
        <!-- END wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/modernizr.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>

        <script src="assets/plugins/chart.js/chart.min.js"></script>
        <script src="assets/pages/dashboard.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>

        <script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const table = document.getElementById('datatable');
    const tableRows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    
    searchInput.addEventListener('input', function() {
        const query = searchInput.value.toLowerCase();
        
        Array.from(tableRows).forEach(row => {
            const cells = row.getElementsByTagName('td');
            let match = false;
            
            // Iterate over each cell in the row
            Array.from(cells).forEach(cell => {
                if (cell.textContent.toLowerCase().includes(query)) {
                    match = true;
                }
            });
            
            // Show or hide the row based on the match
            if (match) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
});

$('#newTeacherForm').submit(function(e) {
    e.preventDefault(); // Prevent default form submission

    console.log("Form submitted!");  // Log form submission

    // Disable the submit button to prevent multiple submissions
    $('#submitButton').prop('disabled', true);

    $.ajax({
        url: 'add_teachers.php', // Your PHP file that adds the teacher
        method: 'POST',
        data: $(this).serialize(), // Serialize form data
        success: function(response) {
            console.log(response);  // Log the response from the PHP backend to the console
            let res = JSON.parse(response); // Parse the JSON response

            // Check the response and show appropriate alert
            if (res.success) {
                alert('Teacher added successfully!');
                $('#newTeacherForm')[0].reset(); // Reset the form after success
                location.reload(); // Reload the page to reflect changes
            } else {
                alert('Error: ' + res.error);
            }
        },
        error: function(xhr, status, error) {
            // In case of a network or server error, show an alert
            alert('An error occurred while adding the teacher: ' + error);
        },
        complete: function() {
            // Re-enable the submit button after the request is complete
            $('#submitButton').prop('disabled', false);
        }
    });
});





function deleteRecord(id) {
    if (confirm('Are you sure you want to delete this record?')) {
        fetch('delete_teacher1.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'id=' + encodeURIComponent(id)
        })
        .then(response => response.text())
        .then(responseText => {
            if (responseText.trim() === 'success') {
                alert('Record deleted successfully');
                location.reload(); // Reload to update the table
            } else {
                alert('Error deleting record: ' + responseText);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to delete record.');
        });
    }
}

function editTeacher(teacherID) {
    // Fetch teacher data based on the TeacherID
    fetch('get_teacher.php?id=' + teacherID)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('editTeacherID').value = data.teacher.TeacherID;
                document.getElementById('editFullName').value = data.teacher.FullName;
                document.getElementById('editEmail').value = data.teacher.Email;
                document.getElementById('editDepartment').value = data.teacher.Department;
                document.getElementById('editDesignation').value = data.teacher.Designation;
                document.getElementById('editPhoneNumber').value = data.teacher.PhoneNumber;
                document.getElementById('editGender').value = data.teacher.Gender;
            } else {
                alert('Failed to fetch teacher data.');
            }
        })
        .catch(error => console.error('Error:', error));
}


// Function to handle the form submission and show success/error messages
// Handle form submission for editing teacher details
document.getElementById('editTeacherForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting normally

    // Prepare form data for AJAX
    const formData = new FormData(this);

    fetch('update_teacher.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Show success message
            alert(data.message);

            // Update the teacher's row in the table
            updateTeacherRow(data.data);

            // Hide the modal
            $('#editTeacherModal').modal('hide');

            // Reload the page to ensure changes are visible
            location.reload();
        } else {
            // Show error message
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while updating the teacher.');
    });
});

// Function to update the table row with new data
function updateTeacherRow(updatedData) {
    // Find the row with the specific TeacherID
    let row = document.querySelector(`tr[data-teacher-id="${updatedData.TeacherID}"]`);

    if (row) {
        // Update each cell with the new data
        row.querySelector('.full-name').textContent = updatedData.FullName;
        row.querySelector('.email').textContent = updatedData.Email;
        row.querySelector('.department').textContent = updatedData.Department;
        row.querySelector('.designation').textContent = updatedData.Designation;
        row.querySelector('.gender').textContent = updatedData.Gender;
        row.querySelector('.phone-number').textContent = updatedData.PhoneNumber;
    }
}


// Function to update the table row dynamically
function updateTeacherRow(updatedData) {
    // Find the table row by TeacherID (this assumes each row has a unique TeacherID)
    let row = document.querySelector(`tr[data-teacher-id="${updatedData.TeacherID}"]`);

    if (row) {
        // Update the row's cells with the new data
        row.querySelector('.full-name').textContent = updatedData.FullName;
        row.querySelector('.email').textContent = updatedData.Email;
        row.querySelector('.department').textContent = updatedData.Department;
        row.querySelector('.designation').textContent = updatedData.Designation;
        row.querySelector('.gender').textContent = updatedData.Gender;
        row.querySelector('.phone-number').textContent = updatedData.PhoneNumber;
    }
}



// function deleteRecord(id) {
//     if (confirm('Are you sure you want to delete this record?')) {
//         fetch('delete_teacher1.php', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/x-www-form-urlencoded'
//             },
//             body: 'id=' + encodeURIComponent(id)
//         })
//         .then(response => response.text())
//         .then(responseText => {
//             if (responseText.trim() === 'success') {
//                 alert('Record deleted successfully');
//                 location.reload(); // Reload to update the table
//             } else {
//                 alert('Error deleting record: ' + responseText);
//             }
//         })
//         .catch(error => {
//             console.error('Error:', error);
//             alert('Failed to delete record.');
//         });
//     }
// }





// function deleteRecord(id, url) {
//     if (confirm('Are you sure you want to delete this record?')) {
//         var xhr = new XMLHttpRequest();
//         xhr.open('POST', url, true);
//         xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
//         xhr.onload = function() {
//              console.log(xhr.responseText)

//             if (xhr.status === 200) {
//                 if (xhr.responseText === 'success') {
//                     alert('Record deleted successfully');

//                     location.reload();
//                 } else {
//                     alert('Error deleting record');
//                 }
//             } else {
//                 alert('Request failed. Returned status of ' + xhr.status);
//             }
//         };
//         xhr.send('id=' + encodeURIComponent(id));
//     }
// }

// // Example usage
// document.addEventListener('DOMContentLoaded', function() {
//     document.querySelectorAll('.delete-btn').forEach(function(button) {
//         button.addEventListener('click', function(event) {
//             event.preventDefault();
            
//             var id = this.getAttribute('data-id');
//             var url = this.getAttribute('data-url');
            
//             deleteRecord(id, url);
//         });
//     });
// });


</script>

<!-- Hidden Print Template -->
<div id="printTemplate" style="display: none;">
    <div class="print-header">
        <img src="../assets/img/logotitle.png" alt="Logo" style="height: 60px;">
        <h2>PSU ASINGAN CAMPUS</h2>
        <h3>Teachers Report by Department</h3>
        <p>Date Generated: <span id="printDate"></span></p>
    </div>
</div>

<script>
function printTeachersByDepartment() {
    // Fetch all teachers data
    fetch('get_teachers_by_department.php')
        .then(response => response.json())
        .then(data => {
            // Create print window content
            let printWindow = window.open('', '_blank');
            let template = document.getElementById('printTemplate').innerHTML;
            
            let content = `
                <html>
                <head>
                    <title>Teachers Report</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        .print-header { text-align: center; margin-bottom: 30px; }
                        .department-section { margin-bottom: 30px; }
                        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        @media print {
                            .no-print { display: none; }
                            body { margin: 0; }
                        }
                    </style>
                </head>
                <body>
                    ${template}
                    <script>
                        document.getElementById('printDate').textContent = new Date().toLocaleDateString();
                    <\/script>
            `;

            // Group teachers by department
            let departments = {};
            data.forEach(teacher => {
                if (!departments[teacher.Department]) {
                    departments[teacher.Department] = [];
                }
                departments[teacher.Department].push(teacher);
            });

            // Create tables for each department
            for (let dept in departments) {
                content += `
                    <div class="department-section">
                        <h3>${dept}</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>Full Name</th>
                                    <th>Designation</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Gender</th>
                                </tr>
                            </thead>
                            <tbody>
                `;

                departments[dept].forEach(teacher => {
                    content += `
                        <tr>
                            <td>${teacher.FullName}</td>
                            <td>${teacher.Designation}</td>
                            <td>${teacher.Email}</td>
                            <td>${teacher.PhoneNumber}</td>
                            <td>${teacher.Gender}</td>
                        </tr>
                    `;
                });

                content += `
                            </tbody>
                        </table>
                    </div>
                `;
            }

            content += `
                    <div class="no-print" style="text-align: center; margin-top: 20px;">
                        <button onclick="window.print()">Print Report</button>
                    </div>
                </body>
                </html>
            `;

            printWindow.document.write(content);
            printWindow.document.close();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error generating report');
        });
}
</script>

        

    </body>
</html>