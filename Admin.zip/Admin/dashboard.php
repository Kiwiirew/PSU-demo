<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>PSU ASINGAN CAMPUS</title>
        <meta content="Admin Dashboard" name="description" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="../assets/img/logotitle.png" type="image/x-icon">
        <link rel="icon" href="../assets/img/logotitle.png" type="image/x-icon">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">

        <link rel="stylesheet" href="assets/css/custom.css">
    </head>

 <!-- oncontextmenu="return false" -->
    <body class="fixed-left">

        <!-- Loader -->
<div class="preloader" id="preloader">
            <div class="lds-ellipsis">
                <span></span>
                 <!-- <span  style="background:#FFAA17"></span> -->
                <span  style="background:#0A27D8"></span>
                <span  style="background: #222429;"></span>
            </div>
        </div>
        <!-- Begin page -->
        <div id="wrapper">

            <!-- ========== Left Sidebar Start ========== -->
            <?php include('leftnavbar.php') ?>
            <!-- Left Sidebar End -->

            <!-- Start right Content here -->

            <div class="content-page">
                <!-- Start content -->
                <div class="content">

                    <!-- Top Bar Start -->
                   
                    <?php include('topnavbar.php') ?>
                    <!-- Top Bar End -->

                    <div class="page-content-wrapper ">

                        <div class="container-fluid">

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="page-title-box">
                                        <div class="btn-group float-right">
                                            <ol class="breadcrumb hide-phone p-0 m-0">
                                                <li class="breadcrumb-item"><a href="#">PSU</a></li>
                                                <li class="breadcrumb-item active">Dashboard</li>
                                            </ol>
                                        </div>
                                        <h4 class="page-title">Welcome to your Dashboard, PSU Asingan!</h4>
                                    </div>
                                </div>
                            </div>
                          
                            <div class="row">
                                
                                <div class="col-xl-4">
                                    <div class="card" style="height:auto;">
                                        <div class="card-body" style="height: auto;">
                                           
                                            <h5 class="header-title pb-3 mt-0">Administrators</h5>

                                            <div class="table-responsive boxscroll" style="overflow: hidden; outline: none;">
                                                

                                                <table class="table mb-0">                                                                
                                                    <tbody>
                                                        <?php
                                                            include 'db_conn.php';

                                                            $sql = "SELECT id, username, password, acctype FROM admin_accounts";
                                                            $result = $conn->query($sql);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $id = htmlspecialchars($row["id"]);
                                                                    $username = htmlspecialchars($row["username"]);
                                                                    $acctype = htmlspecialchars($row["acctype"]);
                                                                    $password = htmlspecialchars($row["password"]);
                                                                    
                                                                    echo '<tr>';
                                                                    echo '<td class="border-top-0">';
                                                                    echo '<div class="media">';
                                                                    echo '<img src="assets/images/admin.svg" alt="" class="thumb-md rounded-circle">';
                                                                    echo '<div class="media-body ml-2">';
                                                                    echo '<p class="mb-0">' . $username . '<span class="badge badge-soft-primary" style="margin-left:5px">' . $acctype . '</span></p>';
                                                                    echo '<span class="font-12 text-muted">' . $password . '</span>';
                                                                    echo '</div>';
                                                                    echo '</div>';
                                                                    echo '</td>';
                                                                    echo '<td class="border-top-0 text-right">';
                                                                    echo '<a href="#" class="btn btn-light btn-sm delete-btn" data-id="' . $id . '" data-url="delete_admin.php"><i class="far fa-trash-alt mr-2 text-danger"></i>Delete</a>';
                                                                    echo '</td>';
                                                                    echo '</tr>';
                                                                }
                                                            } else {
                                                                echo '<tr><td colspan="2">No records found</td></tr>';
                                                            }

                                                            $conn->close();
                                                            ?>                                    
                                                    </tbody>
                                                </table>
                                                                                                    

                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-6">
                                    <div class="card">
                                        <div class="card-body" style="height: auto;">
                                            <a href="#" class="btn float-right" id="btncreate" style="border-color: #0A27D8;">New Admin</a>
                                            <h5 class="header-title mb-4 mt-1">Add New Admins</h5>
                                            <p class="font-14 text-muted mb-4">
                                               Enable existing administrators to create and manage new admin accounts with customizable roles and permissions. This feature ensures secure delegation of responsiblities, allowing specific access to different parts of the dashboard while maintaining overall control and accountability.
                                            </p>                                        
                                        </div>   
                                         <div class="card-body" style="margin:0px">
                                            <a href="teachers" class="btn float-right"  id="btncreate"  style="border-color: #0A27D8;">New Teacher</a>
                                            <h5 class="header-title mb-4 mt-1">Add New Teacher</h5>
                                            <p class="font-14 text-muted mb-4">
                                            Quickly onboard new teachers by creating and managing their accounts with customizable roles and permissions. Grant access to course content and student interactions as needed, while retaining overall control. Enhance your educational team and streamline course management effortlessly.
                                            </p>                                        
                                        </div>                        

                                        <div class="card-body" style="margin:0px">
                                            <a href="students" class="btn float-right"  id="btncreate"  style="border-color: #0A27D8;">New Student</a>
                                            <h5 class="header-title mb-4 mt-1">Add New Student</h5>
                                            <p class="font-14 text-muted mb-4">
                                              Create rich course content and coaching products for your students. When you give them a pricing plan, they'll appear on your site!
                                            </p>                                        
                                        </div>  
                                    </div>
                                   
                                </div>

                                <!-- Modal -->
                                <div class="modal fade" id="newAdminModal" tabindex="-1" role="dialog" aria-labelledby="newAdminModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="newAdminModalLabel">Add New Admin</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form id="newAdminForm">
                                                    <div class="form-group">
                                                        <label for="username">Username</label>
                                                        <input type="text" class="form-control" id="username" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="password">Password</label>
                                                        <input type="password" class="form-control" id="password" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="acctype">Label</label>
                                                        <select class="form-control" id="acctype" required>
                                                            <option value="admin">Faculty</option>
                                                            <option value="superadmin">Moderator</option>
                                                        </select>
                                                    </div>
                                                    <button type="submit" class="btn btn-primary">Create Admin</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                               <div class="col-xl-4">
                                    <div class="card">
                                        <div class="card-body">
                                           
                                            <h5 class="header-title pb-3 mt-0">Teachers</h5>
                                            <div class="table-responsive boxscroll" style="overflow: hidden; outline: none;">
                                                <table class="table mb-0">                                                                
                                                    <tbody>
                                                       
                                                        <?php
                                                            include 'db_conn.php';

                                                            $sql = "SELECT TeacherID, FullName, Department, Gender FROM teachers";
                                                            $result = $conn->query($sql);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                            
                                                                    $imageSrc = ($row['Gender'] == 'Male') ? 'assets/images/manteacher.png' : 'assets/images/womanteacher.svg';
                                                                    
                                                                    echo '<tr>';
                                                                    echo '    <td>';
                                                                    echo '        <div class="media">';
                                                                    echo '            <img src="' . $imageSrc . '" alt="" class="thumb-md rounded-circle">';
                                                                    echo '            <div class="media-body ml-2">';
                                                                    echo '                <p class="mb-0">' . htmlspecialchars($row['FullName']) . '</p>';
                                                                    echo '                <span class="font-12 text-muted">' . htmlspecialchars($row['Department']) . '</span>';
                                                                    echo '            </div>';
                                                                    echo '        </div>';
                                                                    echo '    </td>';
                                                                    echo '    <td class="text-right">';
                                                                    
                                                                    echo '        <a href="#" class="btn btn-light btn-sm delete-btn" data-id="' . htmlspecialchars($row['TeacherID']) . '" data-url="delete_teacher.php"><i class="far fa-trash-alt mr-2 text-danger"></i>Delete</a>';
                                                                    echo '    </td>';
                                                                    echo '</tr>';
                                                                }
                                                            } else {
                                                                echo '<tr><td colspan="2">No teachers found</td></tr>';
                                                            }

                                                            $conn->close();
                                                        ?>

                                                                                                    
                                                    </tbody>

                                                </table>
                                                  <div class="pt-3 text-right" style="width: 100%; height:50px; position: absolute;bottom: 0px;right: 0px;padding-right: 20px; backdrop-filter: blur(10px);">
                                                <a href="teachers" style="color: #0A27D8">View all <i class="mdi mdi-arrow-right"></i></a>
                                            </div> 
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="card">                                
                                        <div class="card-body">
                                            <h5 class="header-title pb-3 mt-0">Students</h5>
                                            <div class="table-responsive">
                                                <table class="table table-hover mb-0">
                                                    <thead>
                                                        <tr class="align-self-center">
                                                            <th>Full Name</th>

                                                            <th>Bachelor Program</th>
                                                            <th>Email</th>
                                                            <th>Phone Number</th>
                                                            <th>Actions</th>                                                                                  
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                          <?php
                                                            include 'db_conn.php'; 

                                                            $sql = "SELECT 
                                                            s.StudentID,
                                                            s.FullName,
                                                            s.EmailAddress,
                                                            s.PhoneNumber,
                                                            e.CourseID,
                                                            c.BachelorProgram
                                                            FROM 
                                                            students s
                                                            INNER JOIN 
                                                            enrollment e ON s.StudentID = e.StudentID
                                                            INNER JOIN 
                                                            courses c ON e.CourseID = c.CourseID
                                                            LIMIT 5;";
                                                            $result = $conn->query($sql);

                                                            if ($result->num_rows > 0) {
                                                            while($row = $result->fetch_assoc()) {
                                                                $studentID = htmlspecialchars($row['StudentID']);
                                                                $fullName = htmlspecialchars($row['FullName']);
                                                                $email = htmlspecialchars($row['EmailAddress']);
                                                                $phone = htmlspecialchars($row['PhoneNumber']);
                                                                $bachelorProgram = htmlspecialchars($row['BachelorProgram']);

                                                                echo '<tr>';
                                                                echo '<td><img src="assets/images/student.png" alt="" class="rounded-circle thumb-sm mr-1"> ' . $fullName . '</td>';
                                                                echo '<td>' . $bachelorProgram . '</td>';
                                                                echo '<td>' . $email . '</td>';
                                                                echo '<td>' . $phone . '</td>';
                                                                echo '<td>';
                                                                
                                                               
                                                                echo '<button type="button" class="btn btn-sm btn-danger delete-btn" data-id="' . $studentID . '" data-url="delete_student.php" style="margin:5px"><i class="fas fa-trash-alt"></i> </button>';
                                                                echo '</td>';
                                                                echo '</tr>';
                                                            }
                                                            } else {
                                                            echo '<tr><td colspan="5">No students found</td></tr>'; 
                                                            }

                                                            $conn->close();
                                                            ?>        
                                                    </tbody>
                                                </table>
                                            </div><!--end table-responsive-->
                                            <div class="pt-3 border-top text-right">
                                                <a href="students" class="text-primary">View all <i class="mdi mdi-arrow-right"></i></a>
                                            </div> 
                                        </div>
                                    </div>                                                                   
                                </div> 
                            </div>
                            <!-- end row -->
                            
                        </div><!-- container -->

                    </div> <!-- Page content Wrapper -->

                </div> <!-- content -->

                <footer class="footer">
                    © 2024 PSU ASINGAN CAMPUS
                </footer>

            </div>
            <!-- End Right content here -->

        </div>
        <!-- END wrapper -->


        <script>
/**
 * Function to handle record deletion with confirmation and AJAX.
 * 
 * @param {number} id - The ID of the record to be deleted.
 * @param {string} url - The URL of the PHP file that handles the deletion.
 */
function deleteRecord(id, url) {
    if (confirm('Are you sure you want to delete this record?')) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
             console.log(xhr.responseText)

            if (xhr.status === 200) {
                if (xhr.responseText === 'success') {
                    alert('Record deleted successfully');

                    location.reload();
                } else {
                    alert('Error deleting record');
                }
            } else {
                alert('Request failed. Returned status of ' + xhr.status);
            }
        };
        xhr.send('id=' + encodeURIComponent(id));
    }
}

// Example usage
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.delete-btn').forEach(function(button) {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            
            var id = this.getAttribute('data-id');
            var url = this.getAttribute('data-url');
            
            deleteRecord(id, url);
        });
    });
});
</script>

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/modernizr.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>

        <script src="assets/plugins/chart.js/chart.min.js"></script>
        <script src="assets/pages/dashboard.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Show modal when create button is clicked
                document.getElementById('btncreate').addEventListener('click', function(event) {
                    event.preventDefault();
                    $('#newAdminModal').modal('show');
                });

                // Handle form submission
                document.getElementById('newAdminForm').addEventListener('submit', function(event) {
                    event.preventDefault();

                    // Create FormData object
                    const formData = new FormData();
                    formData.append('username', document.getElementById('username').value);
                    formData.append('password', document.getElementById('password').value);
                    formData.append('acctype', document.getElementById('acctype').value);

                    // Send data to adminbackend.php via fetch
                    fetch('adminbackend.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.text())
                    .then(data => {
                        try {
                            const result = JSON.parse(data);
                            if (result.success) {
                                alert('Admin created successfully!');
                                $('#newAdminModal').modal('hide');
                                location.reload(); // Reload page to show new admin
                            } else {
                                alert(result.message || 'Failed to create admin');
                            }
                        } catch (e) {
                            console.error('Error parsing response:', data);
                            alert('Failed to create admin. Please try again.');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Failed to create admin. Please try again.');
                    });
                });
            });
            
        </script>

    </body>
</html>