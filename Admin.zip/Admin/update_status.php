<?php
// Include your database connection file
include 'db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from the form
    $record_id = $_POST['record_id']; // Hidden input
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];

    // Validate and sanitize inputs (recommended)
    $record_id = intval($record_id); // Convert to integer
    $fullname = htmlspecialchars($fullname);
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);

    // Update query
    $sql = "UPDATE your_table SET FullName = ?, Email = ? WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssi', $fullname, $email, $record_id);

    if ($stmt->execute()) {
        echo "Record updated successfully!";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>
