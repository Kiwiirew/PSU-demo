<?php
include 'db_conn.php'; 

$sql = "SELECT COUNT(*) as count FROM courses";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $count = $row['count'];
} else {
    $count = 0; 
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>PSU ASINGAN CAMPUS</title>
        <meta content="Admin Dashboard" name="description" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="../assets/img/logotitle.png" type="image/x-icon">
        <link rel="icon" href="../assets/img/logotitle.png" type="image/x-icon">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">

        <link rel="stylesheet" href="assets/css/custom.css">
    </head>

 <!-- oncontextmenu="return false" -->
    <body class="fixed-left">

        <!-- Loader -->
<div class="preloader" id="preloader">
            <div class="lds-ellipsis">
                <span></span>
                 <!-- <span  style="background:#FFAA17"></span> -->
                <span  style="background:#0A27D8"></span>
                <span  style="background: #222429;"></span>
            </div>
        </div>
        <!-- Begin page -->
        <div id="wrapper">

            <!-- ========== Left Sidebar Start ========== -->
            <?php include('leftnavbar.php') ?>
            <!-- Left Sidebar End -->

            <!-- Start right Content here -->

            <div class="content-page">
                <!-- Start content -->
                <div class="content">

                    <!-- Top Bar Start -->
                   
                    <?php include('topnavbar.php') ?>
                    <!-- Top Bar End -->

                    <div class="page-content-wrapper">

                        <div class="container-fluid"  style="padding-top:30px;">

                        
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="card">                                
                                        <div class="card-body">
                                           <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center">
                    <!-- Title -->
                    <h5 class="text-center header-title pb-3 mt-0">All Courses w/ Subjects (<span style="color:#0A27D8"><?php echo $count; ?></span>)</h5>
                    
                    <!-- Right-aligned elements for desktop, centered for mobile -->
                    <div class="d-flex flex-column flex-md-row align-items-md-center mt-3 mt-md-0">
                        <!-- Button and input container -->
                        <div class="text-center text-md-end" style="margin-right: 10px;">
                            <button class="btn btn-primary me-md-2 mb-2 mb-md-0" data-toggle="modal" data-target="#newCourseModal">Add New Course</button>
                            <button class="btn btn-success me-md-2 mb-2 mb-md-0" onclick="printReport()">
                                <i class="fas fa-print"></i> Print Report
                            </button>
                        </div>
                        <div class="text-center text-md-end" style="margin: auto;">
                            <input type="text" id="searchInput" class="form-control" autocomplete="off" placeholder="Search Here" style="max-width: 200px;">
                        </div>
                    </div>
                </div>
                                                <!-- New Course Modal -->
                    <div class="modal fade" id="newCourseModal" tabindex="-1" role="dialog" aria-labelledby="newCourseModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="newCourseModalLabel">Add New Course</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form for Adding New Course -->
                                    <form id="newCourseForm" action="submit_course.php" method="post">
                                        <!-- Course Code Field -->
                                        <div class="form-group">
                                            <label for="courseCode">Course Code</label>
                                            <input type="text" class="form-control" id="courseCode" name="courseCode" required>
                                        </div>
                                        
                                        <!-- Subject Field -->
                                        <div class="form-group">
                                            <label for="subject">Subject</label>
                                            <input type="text" class="form-control" id="subject" name="subject" required>
                                        </div>
                                        
                                        <!-- Department Dropdown Field -->
                                        <div class="form-group">
                                            <label for="department">Department</label>
                                            <select class="form-control" id="department" name="department" required>
                                                <option value="">Select Department</option>
                                                <option value="BSIT">Bachelor of Science in Information Technology</option>
                                                <option value="BSBA">Bachelor of Science in Business Administration</option>
                                                <option value="BTLE">Bachelor of Technology and Livelihood Education</option>
                                                <option value="BEE">Bachelor of Elementary Education</option>
                                                <option value="BSE">Bachelor of Secondary Education</option>
                                                <option value="BIT">Bachelor of Industrial Technology</option>
                                            </select>
                                        </div>
                                        
                                        <!-- Room Field -->
                                        <div class="form-group">
                                            <label for="room">Room</label>
                                            <input type="text" class="form-control" id="room" name="room" required>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" form="newCourseForm" class="btn btn-primary">Save Course</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Edit Course Modal -->
                    <div class="modal fade" id="editCourseModal" tabindex="-1" role="dialog" aria-labelledby="editCourseModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editCourseModalLabel">Edit Course</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form for Editing Course -->
                                    <form id="editCourseForm" action="update_course.php" method="POST">
                                        <input type="hidden" id="editCourseID" name="CourseID">
                                        
                                        <div class="form-group">
                                            <label for="editCourseCode">Course Code</label>
                                            <input type="text" class="form-control" id="editCourseCode" name="CourseCode" required>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="editSubject">Subject</label>
                                            <input type="text" class="form-control" id="editSubject" name="Subject" required>
                                        </div>
                                        
                                        <!-- Department Dropdown Field -->
                                        <div class="form-group">
                                            <label for="editDepartment">Department</label>
                                            <select class="form-control" id="editDepartment" name="Department" required>
                                                <option value="">Select Department</option>
                                                <option value="BSIT">Bachelor of Science in Information Technology</option>
                                                <option value="BSBA">Bachelor of Science in Business Administration</option>
                                                <option value="BTLE">Bachelor of Technology and Livelihood Education</option>
                                                <option value="BEE">Bachelor of Elementary Education</option>
                                                <option value="BSE">Bachelor of Secondary Education</option>
                                                <option value="BIT">Bachelor of Industrial Technology</option>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="editRoom">Room</label>
                                            <input type="text" class="form-control" id="editRoom" name="Room" required>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" form="editCourseForm" class="btn btn-primary">Save Changes</button>
                                </div>
                            </div>
                        </div>
                    </div>


                                            <div class="table-responsive" style="margin-top: 20px;">
                                            <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                    <thead>
                                                        <tr class="align-self-center">
                                                            <th>CourseCode</th>

      <th>BachelorProgram</th>
      <th>Subject</th>
      <!-- <th>Credits</th>
      <th>Schedules</th> -->
      <th>Room</th>

      <th>Department</th>
                                                            <th>Actions</th>                                                                                  
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                           <?php
include 'db_conn.php'; 

$sql = "SELECT * FROM courses";
$result = $conn->query($sql);


if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['CourseCode']) . '</td>';

    
        echo '<td>' . htmlspecialchars($row['Subject']) . '</td>';
        // echo '<td>' . htmlspecialchars($row['Credits']) . '</td>';
        // echo '<td>' . htmlspecialchars($row['Schedules']) . '</td>';
        echo '<td>' . htmlspecialchars($row['Room']) . '</td>';
        
        echo '<td>' . htmlspecialchars($row['Department']) . '</td>';
        echo '<td>';
        // echo '<button type="button" class="btn btn-sm btn-primary" style="margin:5px"><i class="fas fa-eye"></i> View</button>';
        echo '<div class="d-inline-flex" style="gap: 5px;">';
        echo '<button type="button" class="edit-button btn btn-sm" style="margin:5px;background:#FFD500" data-toggle="modal" data-target="#editCourseModal" onclick="editCourse(' . $row['CourseID'] . ')"><i class="fas fa-edit"></i> Edit</button>';
        echo '<button type="button" class="btn btn-sm btn-danger" onclick="deleteRecord(' . $row['CourseID'] . ')"><i class="fas fa-trash-alt"></i></button>';
        echo '</div>';
        echo '</td>';
        echo '</tr>';
    }
} else {

    echo '<tr><td colspan="4">No students found</td></tr>';
}
?>                                                                  
                                                    </tbody>
                                                </table>
                                            </div>
                                           
                                        </div>
                                    </div>                                                                   
                                </div> 
                            </div>
                            <!-- end row -->
                            
                        </div><!-- container -->

                    </div> <!-- Page content Wrapper -->

                </div> <!-- content -->

                <footer class="footer">
                    © 2024 PSU ASINGAN CAMPUS
                </footer>

            </div>
            <!-- End Right content here -->

        </div>
        <!-- END wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/modernizr.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>

        <script src="assets/plugins/chart.js/chart.min.js"></script>
        <script src="assets/pages/dashboard.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>

        <script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const table = document.getElementById('datatable');
    const tableRows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    
    searchInput.addEventListener('input', function() {
        const query = searchInput.value.toLowerCase();
        
        Array.from(tableRows).forEach(row => {
            const cells = row.getElementsByTagName('td');
            let match = false;
            
            Array.from(cells).forEach(cell => {
                if (cell.textContent.toLowerCase().includes(query)) {
                    match = true;
                }
            });
            
            if (match) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
});

function deleteRecord(id) {
    if (confirm('Are you sure you want to delete this record?')) {
        fetch('delete_courses.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'id=' + encodeURIComponent(id)
        })
        .then(response => response.text())
        .then(responseText => {
            if (responseText.trim() === 'success') {
                alert('Record deleted successfully');
                location.reload(); // Reload to update the table
            } else {
                alert('Error deleting record: ' + responseText);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to delete record.');
        });
    }
}

// Function to load course data into the modal form
function editCourse(courseID) {
    fetch('get_course_details.php?id=' + courseID)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data) {
                document.getElementById('editCourseID').value = data.CourseID;
                document.getElementById('editCourseCode').value = data.CourseCode;
                document.getElementById('editSubject').value = data.Subject;
                document.getElementById('editDepartment').value = data.Department;
                document.getElementById('editRoom').value = data.Room;
            } else {
                throw new Error('No data received');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to load course details. Please try again.');
        });
}

// Function to handle the form submission and show success/error messages
document.getElementById('editCourseForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('update_course.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'success') {
            alert('Course updated successfully!');
            location.reload(); // Reload the page to show updated data
        } else {
            alert('Error updating course: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while updating the course. Please try again.');
    });
});

function printReport() {
    // Create a new window for printing
    let printWindow = window.open('', '_blank');
    
    // Get the table content
    let table = document.getElementById('datatable').cloneNode(true);
    
    // Remove the Actions column
    let headers = table.getElementsByTagName('th');
    let rows = table.getElementsByTagName('tr');
    
    // Find the index of the Actions column
    let actionColumnIndex = -1;
    for(let i = 0; i < headers.length; i++) {
        if(headers[i].textContent.trim() === 'Actions') {
            actionColumnIndex = i;
            break;
        }
    }
    
    // Remove the Actions column from all rows
    if(actionColumnIndex !== -1) {
        headers[actionColumnIndex].remove();
        for(let row of rows) {
            let cells = row.getElementsByTagName('td');
            if(cells.length > actionColumnIndex) {
                cells[actionColumnIndex].remove();
            }
        }
    }
    
    // Get the print area content
    let printArea = document.getElementById('printArea').cloneNode(true);
    
    // Create the print content
    let printContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Courses Report</title>
            <style>
                body { font-family: Arial, sans-serif; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .print-header { text-align: center; margin-bottom: 20px; }
                @media print {
                    .print-header { margin-bottom: 20px; }
                    table { page-break-inside: auto; }
                    tr { page-break-inside: avoid; page-break-after: auto; }
                    thead { display: table-header-group; }
                }
            </style>
        </head>
        <body>
            ${printArea.outerHTML}
            ${table.outerHTML}
        </body>
        </html>
    `;
    
    // Write to the new window and print
    printWindow.document.write(printContent);
    printWindow.document.close();
    
    // Wait for the content to load before printing
    printWindow.onload = function() {
        printWindow.print();
        // printWindow.close();
    };
}

</script>

<div id="printArea" style="display: none;">
    <div class="print-header" style="text-align: center; margin-bottom: 20px;">
        <h3>PSU ASINGAN CAMPUS</h3>
        <h4>Courses Report</h4>
        <p>Date Generated: <?php echo date('F d, Y'); ?></p>
    </div>
</div>

    </body>
</html>