<?php
include 'db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']); // Convert to integer for security
    $sql = "SELECT id, name, email, subject, message, created_at FROM contact_feedback WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        echo "<strong>Name:</strong> " . htmlspecialchars($row['name']) . "<br>";
        echo "<strong>Email:</strong> " . htmlspecialchars($row['email']) . "<br>";
        echo "<strong>Subject:</strong> " . htmlspecialchars($row['subject']) . "<br>";
        echo "<strong>Message:</strong> " . htmlspecialchars($row['message']) . "<br>";
        echo "<strong>Date Submitted:</strong> " . htmlspecialchars($row['created_at']);
    } else {
        echo "Feedback not found.";
    }

    $stmt->close();
} else {
    echo "Invalid request.";
}
?>
