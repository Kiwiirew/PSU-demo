<?php
include 'db_conn.php';

// Count feedback
$sql = "SELECT COUNT(*) as count FROM contact_feedback";
$result = $conn->query($sql);
$count = $result ? $result->fetch_assoc()['count'] : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Feedback</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<div id="wrapper">
    <?php include('leftnavbar.php'); ?>
    <div class="content-page">
        <div class="content">
            <?php include('topnavbar.php'); ?>
            <div class="page-content-wrapper">
                <div class="container-fluid" style="padding-top:30px;">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-body">
                                    <h5>All Feedback (<span style="color:#0A27D8"><?php echo $count; ?></span>)</h5>
                                    <input type="text" id="searchInput" class="form-control mb-3" placeholder="Search Here" style="max-width: 300px;">
                                    <div class="table-responsive">
                                        <table id="datatable" class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Subject</th>
                                                    <th>Message</th>
                                                    <th>Date Submitted</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sql = "SELECT id, name, email, subject, message, created_at FROM contact_feedback ORDER BY created_at DESC";
                                                $result = $conn->query($sql);

                                                if ($result && $result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo "<tr>";
                                                        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                                                        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                                                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                                        echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
                                                        echo "<td>" . htmlspecialchars(substr($row['message'], 0, 30)) . "...</td>";
                                                        echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
                                                        echo "<td>
                                                            <button class='btn btn-primary btn-sm view-button' data-id='" . $row['id'] . "'>View</button>
                                                            <button class='btn btn-danger btn-sm delete-button' data-id='" . $row['id'] . "'>Delete</button>
                                                          </td>";
                                                        echo "</tr>";
                                                    }
                                                } else {
                                                    echo '<tr><td colspan="7">No Feedback Found</td></tr>';
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>                                                                   
                        </div> 
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer">© 2024 PSU ASINGAN CAMPUS</footer>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="feedbackModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4>Feedback Details</h4>
                <button type="button" class="btn-close" data-dismiss="modal"></button>
            </div>
            <div class="modal-body"></div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<script>
$(document).ready(function() {
    // Search functionality
    $('#searchInput').on('input', function() {
        const query = $(this).val().toLowerCase();
        $('#datatable tbody tr').each(function() {
            const rowText = $(this).text().toLowerCase();
            $(this).toggle(rowText.includes(query));
        });
    });

    // View feedback
    $('.view-button').on('click', function() {
        const id = $(this).data('id');
        $.post('feedback_details.php', { id: id }, function(response) {
            $('.modal-body').html(response);
            $('#feedbackModal').modal('show');
        });
    });

    // Delete feedback
    $('.delete-button').on('click', function() {
        const id = $(this).data('id');
        if (confirm('Are you sure you want to delete this feedback?')) {
            $.post('delete_feedback.php', { id: id }, function(response) {
                if (response === 'success') {
                    alert('Feedback deleted successfully.');
                    location.reload();
                } else {
                    alert('Failed to delete feedback.');
                }
            });
        }
    });
});
</script>
</body>
</html>
