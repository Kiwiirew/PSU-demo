<?php
include 'db_conn.php'; 

$sql = "SELECT COUNT(*) as count FROM tickets";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $count = $row['count'];
} else {
    $count = 0; 
}

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];

    $query = "UPDATE tickets SET status='$status' WHERE id='$id'"; // Correct table name
    if (mysqli_query($conn, $query)) {
        // Send success response
        echo "Status updated successfully.";
    } else {
        // Send error response
        http_response_code(500); // Set HTTP response code for error
        echo "Error updating status: " . mysqli_error($conn);
    }
    exit; // Prevent further output
}


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>PSU ASINGAN CAMPUS</title>
        <meta content="Admin Dashboard" name="description" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="../assets/img/logotitle.png" type="image/x-icon">
        <link rel="icon" href="../assets/img/logotitle.png" type="image/x-icon">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">

        <link rel="stylesheet" href="assets/css/custom.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>

 <!-- oncontextmenu="return false" -->
    <body class="fixed-left">

        <!-- Loader -->
<div class="preloader" id="preloader">
            <div class="lds-ellipsis">
                <span></span>
                 <!-- <span  style="background:#FFAA17"></span> -->
                <span  style="background:#0A27D8"></span>
                <span  style="background: #222429;"></span>
            </div>
        </div>
        <!-- Begin page -->
        <div id="wrapper">

            <!-- ========== Left Sidebar Start ========== -->
            <?php include('leftnavbar.php') ?>
            <!-- Left Sidebar End -->

            <!-- Start right Content here -->

            <div class="content-page">
                <!-- Start content -->
                <div class="content">

                    <!-- Top Bar Start -->
                   
                    <?php include('topnavbar.php') ?>
                    <!-- Top Bar End -->

                    <div class="page-content-wrapper">

                        <div class="container-fluid"  style="padding-top:30px;">

                        
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="card">                                
                                        <div class="card-body">
                                           <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center">
                    <!-- Title -->
                    <h5 class="text-center header-title pb-3 mt-0">All Tickets (<span style="color:#0A27D8"><?php echo $count; ?></span>)</h5>
                    
                    <!-- Right-aligned elements for desktop, centered for mobile -->
                    <div class="d-flex flex-column flex-md-row align-items-md-center mt-3 mt-md-0">
                        <!-- Button and input container -->
                        <div class="text-center text-md-end" style="margin-right: 10px;">
                        

                        </div>
                        <div class="text-center text-md-end" style="margin: auto;">
                            <input type="text" id="searchInput" class="form-control" autocomplete="off" placeholder="Search Here" style="max-width: 200px;">
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="editTicketModal" tabindex="-1" role="dialog" aria-labelledby="editTicketModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editTicketModalLabel">Update Ticket Status</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="updateStatusForm">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="ticket_status">Status</label>
                                    <select class="form-control" id="ticket_status" name="status" required>
                                        <option value="Verified">Verified</option>
                                        <option value="Unverified">Unverified</option>
                                    </select>
                                </div>
                               
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>



                                            <div class="modal fade" id="empModal" role="dialog">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">Ticket Information</h4>
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                            </div>
                                                            <div class="modal-body"></div>
                                                            <div class="modal-footer"></div>
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>

                                            <div class="table-responsive" style="margin-top: 20px;">
                                            <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                    <thead>
                                                        <tr>
                                                            <th>Ticket ID</th>
                                                            <th>First Name</th>
                                                            <th>Last Name</th>
                                                            <th>Email</th>
                                                            <th>Department</th>
                                                            <th>Screenshot</th>
                                                            <th>Problem Description</th>
                                                            <th>Status</th>
                                                            <th>Actions</th>    
                                                            <th>Verify</th>                                                                               
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            // SQL query to select all data from tickets
                                                            $sql = "SELECT id, first_name, last_name, email, department, screenshot, description, status FROM tickets";

                                                            // Ensure the connection is established
                                                            if ($conn === false) {
                                                                die("Connection failed: " . mysqli_connect_error());
                                                            }

                                                            // Execute the query
                                                            $result = $conn->query($sql);

                                                            // Check if the query was successful
                                                            if ($result === false) {
                                                                echo "Error executing query: " . $conn->error;
                                                            } else {
                                                                if ($result->num_rows > 0) {
                                                                    // Output data of each row
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        echo "<tr>";
                                                                        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                                                                        echo "<td>" . htmlspecialchars($row['first_name']) . "</td>";
                                                                        echo "<td>" . htmlspecialchars($row['last_name']) . "</td>";
                                                                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                                                        echo "<td>" . htmlspecialchars($row['department']) . "</td>";

                                                                        // Display the image with the correct path
                                                                        $screenshots = json_decode($row['screenshot'], true);
                                                                        echo "<td class='text-center'><div style='display: flex; justify-content: center;'>";
                                                                        if (is_array($screenshots) && !empty($screenshots)) {
                                                                            // Display first image as thumbnail
                                                                            echo "<img src='../uploads/" . htmlspecialchars($screenshots[0]) . "' alt='Screenshot' class='img-thumbnail' style='width: 50px; height: auto;'>";
                                                                        } else if (!empty($row['screenshot'])) {
                                                                            // Fallback for single image
                                                                            echo "<img src='../uploads/" . htmlspecialchars($row['screenshot']) . "' alt='Screenshot' class='img-thumbnail' style='width: 50px; height: auto;'>";
                                                                        }
                                                                        echo "</div></td>";

                                                                        echo "<td>" . htmlspecialchars($row['description']) . "</td>";
                                                                        // Display the status
                                                                        // Check the status and output the corresponding label
                                                                        if ($row['status'] == 1) {
                                                                            echo "<td>Unverifed</td>";
                                                                        } elseif ($row['status'] == 2) {
                                                                            echo "<td>Verified</td>";
                                                                        } else {
                                                                            echo "<td>Unknown</td>"; // Optional: handle unexpected values
                                                                        }
                                                                        

                                                                        // Action buttons
                                                                        echo "<td>";
                                                                        
                                                                        echo "<a href='view_ticket.php?id=" . $row['id'] . "' class='btn btn-sm btn-primary'><i class='fas fa-eye'></i> View</a>";

                                                                        echo "<td>";
                                                                       echo '<select onchange="status_update(this.value, ' . htmlspecialchars($row['id']) . ')" class="form-select" style="color: black; background-color: white; ">';
                                                                        echo '<option value="1"' . ($row['status'] == 1 ? ' selected' : '') . '>Unverified</option>';
                                                                        echo '<option value="2"' . ($row['status'] == 2 ? ' selected' : '') . '>Verified</option>';
                                                                        echo '<option value="3"' . ($row['status'] == 3 ? ' selected' : '') . '>Unknown</option>';
                                                                        echo '</select>';
                                                                        echo '</td>';

                                                                        echo "</td>";

                                                                        
                                                                        

                                                                    

                                                                        echo "</tr>";
                                                                    }
                                                                } else {
                                                                    // If no results found
                                                                    echo '<tr><td colspan="9">No Tickets Found</td></tr>';
                                                                }
                                                            }
                                                        ?>
                                      
                                                    </tbody>
                                                </table>
                                            </div><!--end table-responsive-->
                                           
                                        </div>
                                    </div>                                                                   
                                </div> 
                            </div>
                            <!-- end row -->
                            
                        </div><!-- container -->

                    </div> <!-- Page content Wrapper -->

                </div> <!-- content -->

                <footer class="footer">
                    © 2024 PSU ASINGAN CAMPUS
                </footer>

            </div>
            <!-- End Right content here -->

        </div>
        <!-- END wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/modernizr.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>

        <script src="assets/plugins/chart.js/chart.min.js"></script>
        <script src="assets/pages/dashboard.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>


        <script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const table = document.getElementById('datatable');
    const tableRows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    
    searchInput.addEventListener('input', function() {
        const query = searchInput.value.toLowerCase();
        
        Array.from(tableRows).forEach(row => {
            const cells = row.getElementsByTagName('td');
            let match = false;
            
            // Iterate over each cell in the row
            Array.from(cells).forEach(cell => {
                if (cell.textContent.toLowerCase().includes(query)) {
                    match = true;
                }
            });
            
            // Show or hide the row based on the match
            if (match) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
});

$(document).ready(function(){
    $('.view-button').click(function(){
        var id = $(this).data('id');  // Get the id from the data-id attribute
        $.ajax({
            url: 'ajaxfile.php',
            type: 'post',
            data: {id: id},
            success: function(response){
                $('.modal-body').html(response);
                $('#empModal').modal('show');
            }
        })
    });
});


// function status_update(value, id) {
//     let url = "ticketsupport.php"; // Relative path
//     window.location.href = url + "?id=" + id + "&status=" + value;
// }

function status_update(value, id) {
    // Send an AJAX request to update the status
    $.ajax({
        url: 'ticketsupport.php',
        type: 'GET',
        data: { id: id, status: value },
        success: function(response) {
            // Show an alert for successful update
            alert('Status updated successfully!');
            // Reload the page
            location.reload();
        },
        error: function(xhr, status, error) {
            // Show an error message
            alert('Error updating status: ' + error);
        }
    });
}



</script>

        

    </body>
</html>